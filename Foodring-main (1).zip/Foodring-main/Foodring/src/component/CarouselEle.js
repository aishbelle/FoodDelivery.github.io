const CarouselEle = () => {
  return <div>CarouselEle</div>;
};

export default CarouselEle;
